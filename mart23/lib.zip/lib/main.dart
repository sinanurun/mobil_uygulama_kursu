import 'package:flutter/material.dart';
import 'package:mart23/contact_view.dart';

void main(){
  runApp(MaterialApp(
    title: "Liste Uygulaması",
    home: ContactPage(),
  ));
}