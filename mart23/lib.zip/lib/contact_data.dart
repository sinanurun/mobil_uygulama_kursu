class Contact {
  // sabit
  // final(String, List, Object) const

  final String tamad;
  final String eposta;
  const Contact({this.tamad, this.eposta});
}

const iContact = [
  Contact(tamad: "Ahmet", eposta: "ahmetirmak@hotmail.com"),
  Contact(tamad: "Emine", eposta: "eminetanriverdi74@gmail.com"),
  Contact(tamad: "Hüseyin", eposta: "huseyin@gmail.com")
];
